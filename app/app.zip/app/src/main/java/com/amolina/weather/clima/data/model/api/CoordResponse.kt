package com.amolina.weather.clima.data.model.api

data class CoordResponse (

	val lon : Double,
	val lat : Double
)