package com.amolina.weather.clima.ui.location

data class Location(val latitude: Double, val longitude: Double)