package com.amolina.weather.clima.data.model.api

data class CloudListResponse(

    val all: Int
)