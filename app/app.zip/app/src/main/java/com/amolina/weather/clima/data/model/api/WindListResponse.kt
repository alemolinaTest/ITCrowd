package com.amolina.weather.clima.data.model.api

data class WindListResponse(

    val speed: Double?,
    val deg: Double?
)
