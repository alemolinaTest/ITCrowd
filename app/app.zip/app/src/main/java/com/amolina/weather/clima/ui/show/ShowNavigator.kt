package com.amolina.weather.clima.ui.show

/**
 * Created by Amolina on 02/07/19.
 */

interface ShowNavigator {

    fun handleError(throwable: Throwable)
}
