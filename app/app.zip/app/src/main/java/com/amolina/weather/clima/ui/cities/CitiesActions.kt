package com.amolina.weather.clima.ui.cities


sealed class CitiesActions {
    class getCities() : CitiesActions()
}