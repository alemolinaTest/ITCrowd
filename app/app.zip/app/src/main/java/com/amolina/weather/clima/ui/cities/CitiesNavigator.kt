package com.amolina.weather.clima.ui.cities

/**
 * Created by Amolina on 02/07/19.
 */

interface CitiesNavigator {

    fun handleError(throwable: Throwable)
}
