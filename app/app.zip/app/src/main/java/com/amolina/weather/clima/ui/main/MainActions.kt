package com.amolina.weather.clima.ui.main


sealed class MainActions {
    class getLocalForecasts() : MainActions()
}